Male mouse, treated with both PNB and mavacamten at once.
The residual force is not present at all.