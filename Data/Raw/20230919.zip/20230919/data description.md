The muscle started in relaxing solution (SL 2 um) and was subjected to ramps where length was increased from 0.95 Lo to 1.175 Lo
The ramp times were 100s, 10s, 1s, 0.1s.
Two sets of ramps were done in relaxing solution. One set where the order of ramps was slow to fast. A second set where the order was fast to slow.

I also did a fast ramp (0.1s) with a 300s hold after.
The first time I tried this (file 0.1s_ramp_300s_hold_v1.txt) the force transducer baseline had a significant drift, which confounded the measurement.
I also included a Log file (Log_Relax) containing a slow time base recording of the first 2 sets of ramps, plus the ramp with a 300s hold.
In the log file, the baseline drift is quite evident, and you may be able to factor it out of the ramp data.
However, at the end of the experiment, I repeated the long hold (0.1s_ramp_300s_hold_v2.txt), and for this file, there is not appreciable drift. So you should be able to estimate the decay time constant.

Next the muscle was placed in 50 uM PNB to inhibit contraction, and subjected to ramps at various pCa.
You will find the files for the ramps at each pCa, and the slow time-base log files for each pCa.
Note that the lowest calcium (pCa11) is actually just relaxing solution.
So the pCa11 data should be similar to the first set of ramps in relaxing solution (with the exception that PNB is present at pCa11, and the pCa11 data were collected 2 hours later).
