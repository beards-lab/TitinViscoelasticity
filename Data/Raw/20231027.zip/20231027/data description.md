Female mouse
The protocol had 2 modifications you requested.
1) for the relaxed ramps, the order was changed to “slow to fast”, then "fast (with long hold) to slow”
2) In activating solution plus PNB, an extra fast ramp was added to give the sequence: “slow to fast” then "fast with long hold”.

Modification #1 did reduce (but not entirely eliminate) the difference between the two sets of ramps in relaxing solution.
As we discussed, it does seem that when the muscle is preconditioned by a few stretches, then there is a much smaller difference between repeated fast ramps.

Unfortunately, the effect of Modification #2 is hard to assess because in this experiment the stress relaxation was followed by a gradual rise of force.
We saw this in the previous experiment also.
In the previous experiment, I had thought that this rise of force might be due to a problem with the PNB solution.
So for this recent experiment I remade the PNB solution, but the problem remained.
Interestingly, both the last two experiments used muscles from females.
Maybe there is a male/female difference in the effect of PNB to inhibit contraction, with less of an effect in female?