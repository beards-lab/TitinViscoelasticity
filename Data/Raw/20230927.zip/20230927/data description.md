The experiment was done in 3 phases.
1. Relaxed ramps (30 min duration)
2. Activation to measure Fmax (2 min duration)
3. PNB ramps over a range of pCa (40 min duration).

This entire protocol is laid out in the 3 log files containing slow time-base data.
I suggest that you start with these log files, and the experiment should make sense.
By compressing the protocol in this way, it made it much easier for me to automate the measurements.
I plan to use this protocol for the remainder of the experiments.
I think you can still pool this data with the experiment from 09 19 23.
Or, I can repeat the first experiment if needed.

So in more detail, here are the 3 parts of the experiment (the file names should be self-evident.

1) Relax (see log file: Log_relax_ramps)
Ramps are in the order of fast (0.1s) to slow (100s).
Then the order is swapped (slow to fast), and the last ramp of the series (0.1s) has a 300s hold.

You will see that the fast ramp (0.1s) has a higher peak force when delivered first (fast to slow series), compared to when delivered second in (slow to fast series).
I have not seen this behavior before.
It might be an effect of ramp order.
Alternatively, it might simply be that a muscle that has never been stretched is stiffer during the first fast ramp.
Perhaps in the next experiment I should do one conditioning stretch before recording the data.

2) Activation (see log file: Log_Fmax)
No ramps - just measures of passive force, and Fmax (a ktr is also included and some rapid and small length changes to assess cross-bridge attachment)

3) PNB (see log file: Log_PNB)
Ramps 100s to 0.1s in relaxing/PNB.
Then the muscle is activated plus PNB (see the file Fmax_PNB to see that force is almost eliminated)
Then in active muscle with PNB (pCa 4.4), ramps 100s to 0.1s (the 0.1s ramp has a 300s hold).
Finally, 0.1s ramps with pCa changed to 5.5, 5.75, 6 and 6.25. Note that to construct the relationship of stiffness to pCa, you can include the data from the 0.1s ramps in relaxing/PNB (equivalent to pCa 11), and active/PNB (pCa 4.4).

You will see from the log files that there is a lot of drift of the force transducer.
There are multiple points in the protocols when the muscle length is slackened to 80% to measure the true zero.
So you can interpolate the change in the zero force level.
However, please note that when the muscle is moved to a new bath for a solution change (eg. going from relaxed to activating solutions of various pCa), the change in bath will cause discontinuities in the force baseline, and you cannot extrapolate through these.

Finally, I included one file that has a double ramp in PNB pCa 4.4